<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'cnIFYiWCukpHTNTGkqxG3N50ccK8KIIzlocalhost';
$CFG->bootstraphash = '0a36f2b3abaecd487c344f0a6a1e07d5';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
